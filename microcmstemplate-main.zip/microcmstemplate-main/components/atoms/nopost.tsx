function NoPost() {
  return (
    <div className="nopost">
      <p>投稿はありません | No post</p>
    </div>
  )
}

export default NoPost